function y=activate(x)

y = 1*(tanh(x) + 1)/2;
