function classes=classes_from_outputs(outputs)

[values, classes] = max(outputs, [], 2);