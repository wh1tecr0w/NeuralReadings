function y=activate_derivative(x)

y = 1*(1 - tanh(x).^2)/2;