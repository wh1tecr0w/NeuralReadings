Neural Net Example Code
------------------------

These are the files for the tutorial: 15 Steps to Implement a Neural Net on http://www.code-spot.co.za/

The main file is train_app_main (for a stats analysis) or train (for a single run.

plot_data in train.m controls whether or not to plaot graphs.

The code sworks on both Matlab and Octave.

Any querries, suggestions, bug reports can be sent to me at herman.tulleken@gmail.com.



