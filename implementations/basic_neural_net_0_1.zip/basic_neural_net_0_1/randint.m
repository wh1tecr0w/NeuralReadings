function y=randint(m, n, range)

y=floor(rand(m, n)*range);