#include "RndInt.h"
#include <ACG.h>

extern ACG rng;
extern RandomInteger randInt;
